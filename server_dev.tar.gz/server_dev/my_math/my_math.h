#ifndef __TECH_MY_MATH__
#define __TECH_MY_MATH__


void handle_math_func();
#endif
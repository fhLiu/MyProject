#include <iostream>
#include "my_math.h"

using namespace std;

int main()
{
	cout<<"hello world!"<<endl;
	handle_math_func();
	return 0;
}